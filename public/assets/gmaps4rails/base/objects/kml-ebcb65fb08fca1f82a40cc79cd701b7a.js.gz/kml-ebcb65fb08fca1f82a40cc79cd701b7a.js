(function() {
  this.Gmaps4Rails.Kml = {};

  this.Gmaps4Rails.Kml.Instance = {
    DEFAULT_CONF: {
      clickable: true,
      preserveViewport: false,
      suppressInfoWindows: false
    }
  };

}).call(this);
