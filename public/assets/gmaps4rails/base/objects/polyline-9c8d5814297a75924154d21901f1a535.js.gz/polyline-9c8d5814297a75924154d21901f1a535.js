(function() {
  this.Gmaps4Rails.Polyline = {};

  this.Gmaps4Rails.Polyline.Class = {
    DEFAULT_CONF: {
      strokeColor: "#FF0000",
      strokeOpacity: 1,
      strokeWeight: 2,
      clickable: false,
      zIndex: null,
      icons: null
    }
  };

}).call(this);
