(function() {
  this.Gmaps4Rails.Polygon = {};

  this.Gmaps4Rails.Polygon.Class = {
    DEFAULT_CONF: {
      strokeColor: "#FFAA00",
      strokeOpacity: 0.8,
      strokeWeight: 2,
      fillColor: "#000000",
      fillOpacity: 0.35,
      clickable: false
    }
  };

}).call(this);
