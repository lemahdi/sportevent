(function() {
  this.Gmaps4Rails.Circle = {};

  this.Gmaps4Rails.Circle.Class = {
    DEFAULT_CONF: {
      fillColor: "#00AAFF",
      fillOpacity: 0.35,
      strokeColor: "#FFAA00",
      strokeOpacity: 0.8,
      strokeWeight: 2,
      clickable: false,
      zIndex: null
    }
  };

}).call(this);
